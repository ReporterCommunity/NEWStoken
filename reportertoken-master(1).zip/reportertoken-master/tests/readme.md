TEST
====

see test2.log vs 

https://docs.google.com/spreadsheets/d/1g6Xg-CW_K48fmB54HyNkMzVAdNO-g-7RWbH1yXRT9pg/edit?usp=sharing

