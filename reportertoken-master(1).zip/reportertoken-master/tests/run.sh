clear
go run  icotest.go linker.go scriptkiddie.go setup.go contracts.go launcher.go runner.go  sendEth.go transactors.go canary.go