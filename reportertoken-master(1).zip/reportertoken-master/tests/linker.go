package main

func areContractsLinked() bool {
	return true
}
