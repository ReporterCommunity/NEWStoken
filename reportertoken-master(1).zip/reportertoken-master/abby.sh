abigen --sol reporterTest.sol --pkg main --out tests/contracts.go 
